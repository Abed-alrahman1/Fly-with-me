package com.example.visualvortex.entities.User;

public enum UserRole {
    USER, ADMIN, TEACHER
}
