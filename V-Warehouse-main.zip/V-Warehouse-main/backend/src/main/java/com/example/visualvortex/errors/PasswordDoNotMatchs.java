package com.example.visualvortex.errors;

public class PasswordDoNotMatchs extends RuntimeException{
}
