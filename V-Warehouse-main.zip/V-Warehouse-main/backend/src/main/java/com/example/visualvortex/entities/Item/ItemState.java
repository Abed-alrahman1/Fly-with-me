package com.example.visualvortex.entities.Item;

public enum ItemState {
    DAMAGED,
    IN_MAINTENANCE,
    AVAILABLE,
    TAKEN,
}
