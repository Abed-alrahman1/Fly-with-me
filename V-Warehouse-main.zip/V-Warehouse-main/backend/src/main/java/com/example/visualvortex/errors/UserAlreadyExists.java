package com.example.visualvortex.errors;

public class UserAlreadyExists extends RuntimeException{
}
